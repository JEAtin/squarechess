from game import Game

if __name__ == '__main__':
    print("Welcome to the squareChess!\n"
          "This is a puzzle game. Let me show you how to play it.\n"
          "Hope you can have a good game experience ~\n")

    print("Any number of players, any size of the chessboard\n")

    game = Game()