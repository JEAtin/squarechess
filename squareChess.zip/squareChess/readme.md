squareChess
### Any number of players, any size of the chessboard
### Before the game starts, enter the size of the board (size*size) and the number of players (n).
### After the game starts, n players play chess in order
### Players can input X,y to indicate the location of the pieces, the pieces can not overlap
### Each player can set their own piece symbols, symbols can not be repeated
### Players can enter help to view the rules of the game
### Players can exit the game by typing exit
### A player wins when his pieces form a 2-by-2 square
### When n-1 players quit the game, the last player wins
### A tie occurs when there are pieces in all positions on the board
